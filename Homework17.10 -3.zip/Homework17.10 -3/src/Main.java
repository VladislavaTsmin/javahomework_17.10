//Когда закончится учебный год (isYearFinished) и если будет солнечная погода
// (isGoodWeather), то ребята пойдут в поход. Если тур кружок закупит дождевики
// (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
// В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится от сдачи
// тренерского экзамена (isJimFree), или тренер Кейт, если она вернётся из путешествия
// (hasKateComeBack). Вести детей может только один тренер.
// Если Джим и Кейт смогут вести детей вместе,
// то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
public class Main {
    public static void main(String[] args) {
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoats = true ;
        boolean isJimFree = false;
        boolean hasKateComeBack = true;
        boolean isYearFinished = (isJimFree^hasKateComeBack)&&(isGoodWeather||hasBoughtRaincoats);
        System.out.println(isYearFinished);


    }
}