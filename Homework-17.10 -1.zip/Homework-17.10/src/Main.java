import java.util.Scanner;

//Дана длина в метрах. Напишите программу,
// которая переводит указанное значение в км, мили, футы и аршины.
// Выведите начальное и конвертированные значения на экран.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите число в метрах: ");
        double m = scn.nextFloat();
        double k = m / 1000;
        System.out.println("Ваше число в километрах: ");
        System.out.println(k);
        double mil = m / 1609;
        System.out.println("Ваше число в милях: ");
        System.out.println(mil);
        double f = m * 3.281;
        System.out.println("Ваше число в футах: ");
        System.out.println(f);
        double a = m / 0.7112;
        System.out.println("Ваше число в аршинах: ");
        System.out.println(a);


    }
}