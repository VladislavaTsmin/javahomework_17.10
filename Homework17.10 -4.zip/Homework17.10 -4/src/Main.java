import java.util.Scanner;

//Пользователь вводит целое число.
// Напишите программу, которая делит это число на 2 и выводит результат.
// Остаток деления можно отбросить.
// Операторы деления /, умножения * и остатка от деления % применять нельзя.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите число которое хотите поделить на 2: ");
        int num = scn.nextInt();
        System.out.println("Ваше число поделенное на 2 (остаток деления отбрасывается):  ");
        System.out.println(num >> 1);







    }
}