import java.util.Scanner;

//Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
// Выведите сумму сдачи в виде “X рублей и Y копеек”.
public class Main {
    public static void main(String[] args) {
        System.out.println("Между целыми(рублями) и после запятой(копеек) чисел нужно ставить знак запятой ',' ");
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите стоимость покупок: ");
        float product = scn.nextFloat();
        System.out.println("Введите сумму денег, что дал покупатель: ");
        float sum = scn.nextFloat();
        float rest =  product - sum;
        int i = (int)rest;
        double d = rest - i;
        System.out.println("Сдача: " + i +" рублей, " + d + " копеек");

    }
}